''''

Title: Fdn 100 Assignment 06 -- functions and classes
Dev: Thomas Wright
Date: 4/30/2018
ChangeLog: None

Description:
This program is a To-Do list that lists the task and its priority.
The program interacts with a text file. It allows the user to:
** see the current contents of the file
** Add a new item
** Remove an existing item.
** Save Data to File
** Exit Program without saving
It will present the user with the above options and utilizing dictionaries to store the pairs.

The functions are grouped together into a class, which is used to abstract and modularize the code

Input:
There are two forms of input:
1. The contents of Todo.txt
2. User generated input

Output:
Stores the user input to a file with a comma separating the task and its priorities.
The input file will be over-written each time to allow for ease of formatting and to aid in deleting items
The data will resemble rows
It will be easy to read into python as a csv!

'''

## -- Data -- ##

filepath = 'Todo2.txt'

lst_of_dicts = []

user_choice = None
user_task = None
user_priority = None
user_idx = None
user_save = None

## -- Processing -- ##

## Helper functions


class TaskList(object):

    def LoadData(filepath):
        output_lst = []
        with open(filepath, 'r+') as file:
            lst_values = file.readlines()
            lst_values = [i.strip() for i in lst_values]
            lst_values = [i.split(',') for i in lst_values]
            del(lst_values[0])

        for lst in lst_values:
            d = {'Task':lst[0].capitalize(), 'Priority':lst[1].capitalize()}
            output_lst.append(d)
        return output_lst


    def add_item(lst, task, priority):
        d = {'Task':task.capitalize(), 'Priority':priority.capitalize()}
        lst.append(d)

    def delete_index(lst, idx):
        del[lst[idx]]


    def delete_value(lst, word):
        out_lst = [i for i in lst if word.capitalize() not in i.values()]
        num_deleted = len(lst) - len(out_lst)
        if num_deleted > 0:
            return out_lst
        else:
            return num_deleted


    def save_data(lst, filename):
        with open(filename, 'w+') as file:
            file.write('Task' + ',' + 'Priority' + '\n')
            for d in lst:
                file.write(d['Task'] + ',' + d['Priority'] + '\n')


## -- Presentation (I/O)


## Printing functions
def print_list(lst):
    print('')
    print( 'Your to-do list is:')
    for d in lst:
        print('Task: ' + d['Task'] + ',' + ' Priority: ' + d['Priority'])

def print_list_index(lst):
    print('')
    print('Your to-do list is:')
    print('Index  ' + 'Task' + ' : ' + 'Priority')
    for idx, d in enumerate(lst):
        print(str(idx), d['Task'], d['Priority'])


## Loading the intial data

lst_of_dicts = TaskList.LoadData(filepath)

## Running the program

print('Welcome to your To-Do List')
print("Let's get started!")


while user_choice != 6:
    print('''
    Options Menu
    
    1) Show current To-Do list
    2) Add a new Task
    3) Remove an existing Task
    4) Save Data to File
    5) Reset the Data
    6) Exit Program
    ''')

    try:
        user_choice = int(input('Please select a number: '))
    except:
        print('invalid entry')
        continue

    if user_choice == 1:
        print_list(lst_of_dicts)
    elif user_choice == 2:
        user_task = input('Enter a task name: ')
        user_priority = input('Enter the priority (high/medium/low): ')
        TaskList.add_item(lst_of_dicts, user_task, user_priority)
    elif user_choice == 3:
        print('Do you want to delete by index or name?')
        print('Name will delete all occurences of the task.')
        done = False
        while not done:
            delete_option = input('Enter I for index, N for name, or E to exit to program menu: ')
            if delete_option.lower() == 'i':
                while True:
                    print_list_index(lst_of_dicts)
                    try:
                        user_idx = input('Enter the index to delete, E To exit to menu: ')
                        if user_idx.lower() == 'e':
                            done = True
                            break
                        user_idx = int(user_idx)
                        d = lst_of_dicts[user_idx]
                        TaskList.delete_index(lst_of_dicts, int(user_idx))
                        print(d, 'successfully deleted')
                        done = True
                        break
                    except:
                        print('Invalid index - must be in the following print list')
            elif delete_option.lower() == 'n':
                while True:
                    print_list(lst_of_dicts)
                    word = input("Enter the Task to delete or 'E' to exit: ")
                    if word.lower() == 'e':
                        done = True
                        break
                    data_saved = TaskList.delete_value(lst_of_dicts, word)
                    if data_saved:
                        lst_of_dicts = data_saved
                        print('All occurences of', word, 'successfully deleted')
                        done = True
                        break
                    else:
                        print('Task not in the list')
                        print('Please enter the Task to delete again')
            elif delete_option.lower() == 'e':
                done = True
            else:
                print('Incorrect entry.')
    elif user_choice == 4:
        print('Do you want to save to file? (y/n)')
        user_save = input('Enter y or n: ')
        if user_save.lower() == 'y':
            TaskList.save_data(lst_of_dicts, filepath)
            print('data saved to file:', filepath)
        elif user_save.lower() == 'n':
            print('Data not saved to file')
            print('The current program still holds your modified data')
    elif user_choice == 5:
        lst_of_dicts = TaskList.LoadData(filepath)
        print('Data restored to original form')
    elif user_choice == 6:
        print('Great work today!')
        print('See you soon!')
    else:
        print('Incorrect entry, select a number 1-5!')



input('Press Enter to Exit: ')

