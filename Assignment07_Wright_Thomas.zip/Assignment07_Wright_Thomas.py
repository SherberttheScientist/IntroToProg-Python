'''

Title: Fdn 100 Assignment 07 -- Exception Handling and Pickling
Dev: Thomas Wright
Date: 5/13/2018
ChangeLog: None

Description:
This program generates frequency counts of words in a text file
The program return the Top n words and save it to a pickle file
The user will supply
    the text filename,
    n in Top n,
    the name of the file to save to,
    and the name of the shelf to store the data in

Input:
a filename/path provided by the user containing a text file

Output:
Stores the Top n words in the file to a pickle file provided by the user

'''

## -- Data -- ##

## Packages
import os
import shelve
import operator

## Global Variables
done = False
word_lst = None
int_n = None
freq_dict = None
top_n = None
filename = None
shelfname = None



## -- Processing -- ##

## Helper functions


def get_wd():
    return os.listdir(os.getcwd())

def load_words(filepath):
    with open(filepath) as file:
        word_lst = []
        for line in file:
            temp_lst = line.split(' ')
            word_lst += temp_lst
        word_lst = [i.strip('.][,;:\n') for i in word_lst]
        word_lst = [i for i in word_lst if i != i.upper()]
    return word_lst

def freq_count_dict(word_list):
    d = {}
    for word in word_list:
        d[word] = d.get(word, 0) + 1
    return d

def top_freqs(freq_dict, n):
    lst_sorted_dict = sorted(freq_dict.items(), key=operator.itemgetter(1), reverse = True)
    return lst_sorted_dict[:n]


def get_keys(filename):
    s = shelve.open(filename)
    slist = list(s.keys())
    return slist

def modify_shelf(filename, shelfname, obj):
    s = shelve.open(filename)
    s[shelfname] = obj
    s.sync()
    s.close()





## -- Presentation and I/O


## Printing functions
def welcome():
    print('Welcome to the Frequency Counter')
    print('This Program accepts a text file as input')
    print('It returns a list of the most commonly used words with their frequencies')

def y_or_n():
    return input('y or n: ').lower()

def print_wd():
    print('Your current working directory is ')
    print(get_wd())
    print('You can also enter a file name with its full file path.')

## Main program loop

def main():

    ## Creating the word list
    done = False
    while not done:
        print('\nWhich text file would you like to examine?')
        print('')
        print_wd()
        print('')
        filename = input('Enter a filename: ')
        try:
            word_lst = load_words(filename)
        except FileNotFoundError:
            print('Incorrect filename!')
            print('please try again')
            continue
        except:
            print('Something went wrong!')
            print('Please pick a filename from the printed list or double check your filepath')
            continue
        else:
            print('\n' + filename + ' successfully loaded' + '\n')
            print('There are {} unique words in your word list with a total of {} words'.format(len(set(word_lst)), len(word_lst)))
            done = True


    ## Constructing the frequency dictionary

    try:
        freq_dict = freq_count_dict(word_lst)
    except:
        print('There was an error - check the input list')

    ## Asking the user for n in the Top n words in terms of frequency
    ## Returns a list

    done = False
    while not done:
        try:
            print('\n\nThe Program will return the Top n more frequent words in descending order.')
            print('Please select how many words you wish to return.')
            print('For example, for the Top 10 words - enter 10.')
            print('If you enter a number greater than the number of unique words, all words will be returned with their frequencies\n')
            int_n = int(input('Please input an integer: '))
            top_n = top_freqs(freq_dict, int_n)
        except ValueError:
            print('Please enter a positive integer - a whole number')
            continue
        except:
            print('An error occurred, please try again')
            continue
        else:
            print('\n\nThe Top {} words are: '.format(int_n))
            print(top_n)
            done = True

    ## Saving the Top n list to file

    done = False
    while not done:
        try:
            print('\n\nYou have two options for saving the data to file: ')
            print('Type a new filename to create a new file')
            print('To append to an existing file, select a file.\n\n')
            print_wd()
            print("\nfilename must have the extension '.dat'")
            filename = input('Enter filename: ')
            if filename[-4:] != '.dat':
                print("\nfilename must have the extension '.dat'")
                continue

            print('\nThe current keys in the shelve are: ', get_keys(str(filename)))

            print('What do you want to name this key?')
            print('Choosing an existing name will overwrite that data.\n')
            shelfname = input('Enter a key name: ')

            modify_shelf(filename, shelfname, top_n)
        except:
            print('An error occured in saving the data to a shelf')
            print('Make sure the file name ends in .dat')
            continue
        else:
            print('data added to {} under the key (or shelf name) of {}'.format(filename, shelfname))
            print('\n\n\n')
            done = True


## Running the program

welcome()

done = False
while not done:
    try:
        main()
    except:
        print('There is an error in the main function')
    else:
        while True:
            print('Do you want to make another Top n frequency list?')
            user_in = y_or_n()
            if user_in == 'y':
                print('Starting new frequency compiler')
                break
            elif user_in == 'n':
                print('Exiting Program: ')
                done = True
                break
            else:
                print('Invalid selection. Please enter y or n')


input('Press Enter to exit: ')




