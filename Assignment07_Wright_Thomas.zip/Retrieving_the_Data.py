
import shelve

def get_data(filename, key):
    s = shelve.open(filename)
    return s[key]

cat = get_data('sherb.dat', 'top_8')

print(cat)

